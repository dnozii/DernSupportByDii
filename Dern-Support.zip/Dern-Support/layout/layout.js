// Fix the login button handlers and add individual support booking
function initModals() {
  const loginBtn = document.getElementById("loginBtn")
  const mobileLoginBtn = document.getElementById("mobileLoginBtn")
  const createAccountBtn = document.getElementById("createAccountBtn")

  // Desktop login button
  if (loginBtn) {
    loginBtn.addEventListener("click", () => {
      window.location.href = "login.html"
    })
  }

  // Mobile login button
  if (mobileLoginBtn) {
    mobileLoginBtn.addEventListener("click", () => {
      window.location.href = "login.html"
    })
  }

  // Create account button
  if (createAccountBtn) {
    createAccountBtn.addEventListener("click", () => {
      window.location.href = "login.html"
    })
  }
}

// Add individual support booking functionality
function initServiceBooking() {
  // Handle all service buttons
  const serviceButtons = document.querySelectorAll(".service-btn")

  serviceButtons.forEach((button) => {
    button.addEventListener("click", function (e) {
      e.preventDefault()

      const buttonText = this.textContent.trim()
      const href = this.getAttribute("href")

      // Handle different service actions
      if (buttonText.includes("Book Session") || buttonText.includes("Get Started")) {
        // Redirect to support request page
        window.location.href = "support-request.html"
      } else if (buttonText.includes("Explore Now")) {
        // Redirect to knowledge base
        window.location.href = "knowledge-base.html"
      } else if (href) {
        // Use the original href
        window.location.href = href
      }
    })
  })
}

// Theme Management
function initTheme() {
  const themeToggle = document.getElementById("themeToggle")
  const mobileThemeToggle = document.getElementById("mobileThemeToggle")

  // Get saved theme or default to dark
  const savedTheme = localStorage.getItem("theme") || "dark"
  document.documentElement.setAttribute("data-theme", savedTheme)

  // Theme toggle handlers
  if (themeToggle) {
    themeToggle.addEventListener("click", toggleTheme)
  }

  if (mobileThemeToggle) {
    mobileThemeToggle.addEventListener("click", toggleTheme)
  }

  function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute("data-theme")
    const newTheme = currentTheme === "dark" ? "light" : "dark"

    document.documentElement.setAttribute("data-theme", newTheme)
    localStorage.setItem("theme", newTheme)
  }
}

// Background Canvas Animation
function initBackgroundCanvas() {
  const canvas = document.getElementById("backgroundCanvas")
  if (!canvas) return

  const ctx = canvas.getContext("2d")

  // Set canvas dimensions
  function setCanvasDimensions() {
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight
  }

  setCanvasDimensions()
  window.addEventListener("resize", setCanvasDimensions)

  // Particle class
  class Particle {
    constructor() {
      this.x = Math.random() * canvas.width
      this.y = Math.random() * canvas.height
      this.size = Math.random() * 3 + 1
      this.speedX = (Math.random() - 0.5) * 0.5
      this.speedY = (Math.random() - 0.5) * 0.5
      this.color = `rgba(${Math.floor(Math.random() * 100 + 155)}, ${Math.floor(Math.random() * 100 + 155)}, ${Math.floor(Math.random() * 255)}, `
      this.alpha = Math.random() * 0.5 + 0.1
    }

    update() {
      this.x += this.speedX
      this.y += this.speedY

      if (this.x < 0 || this.x > canvas.width) this.speedX *= -1
      if (this.y < 0 || this.y > canvas.height) this.speedY *= -1
    }

    draw() {
      ctx.beginPath()
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2)
      ctx.fillStyle = this.color + this.alpha + ")"
      ctx.fill()
    }
  }

  // Create particles
  const particles = []
  const particleCount = Math.min(100, Math.floor((window.innerWidth * window.innerHeight) / 10000))

  for (let i = 0; i < particleCount; i++) {
    particles.push(new Particle())
  }

  // Animation loop
  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw grid
    ctx.strokeStyle = "rgba(147, 51, 234, 0.05)"
    ctx.lineWidth = 1

    const gridSize = 50
    for (let x = 0; x < canvas.width; x += gridSize) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, canvas.height)
      ctx.stroke()
    }

    for (let y = 0; y < canvas.height; y += gridSize) {
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(canvas.width, y)
      ctx.stroke()
    }

    // Update and draw particles
    particles.forEach((particle) => {
      particle.update()
      particle.draw()
    })

    // Draw connections
    ctx.strokeStyle = "rgba(147, 51, 234, 0.1)"
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x
        const dy = particles[i].y - particles[j].y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < 100) {
          ctx.beginPath()
          ctx.moveTo(particles[i].x, particles[i].y)
          ctx.lineTo(particles[j].x, particles[j].y)
          ctx.stroke()
        }
      }
    }

    requestAnimationFrame(animate)
  }

  animate()
}

// Navbar scroll effect
function initNavbarScroll() {
  const navbar = document.querySelector(".navbar")

  function handleScroll() {
    if (window.scrollY > 10) {
      navbar.classList.add("scrolled")
    } else {
      navbar.classList.remove("scrolled")
    }
  }

  window.addEventListener("scroll", handleScroll)
  handleScroll() // Initial check
}
function initMobileMenu() {}
function initTabs() {}
function initForms() {}
function initBackToTop() {}

// Update the main DOMContentLoaded event
document.addEventListener("DOMContentLoaded", () => {
  // Set current year in footer
  const currentYearElement = document.getElementById("currentYear")
  if (currentYearElement) {
    currentYearElement.textContent = new Date().getFullYear()
  }

  // Initialize all components
  initTheme()
  initBackgroundCanvas()
  initNavbarScroll()
  initMobileMenu()
  initTabs()
  initForms()
  initBackToTop()
  initModals()
  initServiceBooking() // Add this new function

  // Handle create account button specifically
  const createAccountBtn = document.getElementById("createAccountBtn")
  if (createAccountBtn) {
    createAccountBtn.addEventListener("click", () => {
      window.location.href = "login.html"
    })
  }
})
