"use client"

import { useState } from "react"
import Link from "next/link"
import { User, Building } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"

export default function LoginPage() {
  const [accountType, setAccountType] = useState<'individual' | 'business'>('individual')
  
  return (
    <div className="min-h-screen pt-24 pb-16 px-4 flex flex-col">
      <div className="container mx-auto max-w-6xl flex-grow">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-4 glow-text">
                Welcome to <span className="gradient-text">Dern-Support</span>
              </h1>
              <p className="text-lg text-gray-300">
                Log in to your account or create a new one to access our IT support services.
              </p>
            </div>
            
            <div className="bg-black/40 border border-purple-900/50 backdrop-blur-sm p-6 rounded-lg space-y-4">
              <h3 className="text-xl font-semibold gradient-text">Why Create an Account?</h3>
              
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-lg bg-purple-900/30 flex items-center justify-center mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-medium text-white">Track Support Requests</h4>
                  <p className="text-gray-300 text-sm">
                    View the status of your current and past support requests in one place.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-lg bg-purple-900/30 flex items-center justify-center mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-medium text-white">Faster Service</h4>
                  <p className="text-gray-300 text-sm">
                    We'll remember your details for quicker support in the future.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-lg bg-purple-900/30 flex items-center justify-center mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-medium text-white">Convenient Billing</h4>
                  <p className="text-gray-300 text-sm">
                    Access your invoices and payment history at any time.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid grid-cols-2 mb-6">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <Card className="bg-black/40 border border-purple-900/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Login to Your Account</CardTitle>
                    <CardDescription>Enter your credentials to access your account</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input 
                        id="email" 
                        type="email" 
                        placeholder="name@example.com" 
                        className="bg-black/60 border-purple-900/50 focus:border-purple-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="password">Password</Label>
                        <Link href="/forgot-password" className="text-xs text-purple-400 hover:text-purple-300">
                          Forgot password?
                        </Link>
                      </div>
                      <Input 
                        id="password" 
                        type="password" 
                        className="bg-black/60 border-purple-900/50 focus:border-purple-500"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="remember" />
                      <label
                        htmlFor="remember"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Remember me
                      </label>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                      Login
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              
              <TabsContent value="register">
                <Card className="bg-black/40 border border-purple-900/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Create an Account</CardTitle>
                    <CardDescription>Sign up for a new Dern-Support account</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex space-x-4 p-2 bg-black/60 rounded-lg mb-2">
                      <Button
                        type="button"
                        variant={accountType === 'individual' ? 'default' : 'outline'}
                        className={`w-full ${accountType === 'individual' ? 'bg-purple-600 hover:bg-purple-700' : 'border-purple-600 hover:bg-purple-900/20'}`}
                        onClick={() => setAccountType('individual')}
                      >
                        <User className="mr-2 h-4 w-4" />
                        Individual
                      </Button>
                      <Button
                        type="button"
                        variant={accountType === 'business' ? 'default' : 'outline'}
                        className={`w-full ${accountType === 'business' ? 'bg-purple-600 hover:bg-purple-700' : 'border-purple-600 hover:bg-purple-900/20'}`}
                        onClick={() => setAccountType('business')}
                      >
                        <Building className="mr\
